const tape = require('tape')
const topogram = require('../')

tape('Testing, testing', function(test) {
  test.equal(true, true);
  test.end();
})
